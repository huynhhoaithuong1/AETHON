import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import { createServer } from 'http';
import { WebSocketServer } from 'ws';
import dotenv from 'dotenv';
import { rateLimit } from 'express-rate-limit';

import chatRouter from './routes/chat.js';
import agentsRouter from './routes/agents.js';
import tasksRouter from './routes/tasks.js';
import toolsRouter from './routes/tools.js';
import terminalRouter from './routes/terminal.js';
import modelsRouter from './routes/models.js';
import { setupWebSocket } from './websocket/handler.js';
import { AgentManager } from './agents/manager.js';

dotenv.config();

const app = express();
const httpServer = createServer(app);
const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

// Global agent manager
export const agentManager = new AgentManager();

// Middleware
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: process.env.CORS_ORIGIN || '*', credentials: true }));
app.use(morgan('dev'));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Rate limiting
const limiter = rateLimit({
  windowMs: 60 * 1000,
  max: parseInt(process.env.RATE_LIMIT_MAX || '100'),
  standardHeaders: true,
  legacyHeaders: false,
});
app.use('/api', limiter);

// Health check
app.get('/health', (req, res) => {
  res.json({
    status: 'online',
    timestamp: new Date().toISOString(),
    version: '1.0.0',
    agents: agentManager.getStats(),
  });
});

// Routes
app.use('/api/chat', chatRouter);
app.use('/api/agents', agentsRouter);
app.use('/api/tasks', tasksRouter);
app.use('/api/tools', toolsRouter);
app.use('/api/terminal', terminalRouter);
app.use('/api/models', modelsRouter);

// WebSocket setup
setupWebSocket(wss);

// Error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(err.status || 500).json({
    error: err.message || 'Internal server error',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack }),
  });
});

const PORT = process.env.PORT || 3001;
httpServer.listen(PORT, () => {
  console.log(`\n🔥 AETHON Backend running on http://localhost:${PORT}`);
  console.log(`📡 WebSocket ready at ws://localhost:${PORT}/ws`);
  console.log(`🤖 AI Providers: OpenAI | Gemini | Claude\n`);
});

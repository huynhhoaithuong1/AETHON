import { v4 as uuid } from 'uuid';
import { streamChat } from '../config/aiRouter.js';
import { agentManager } from '../index.js';

const clients = new Map();

export function setupWebSocket(wss) {
  wss.on('connection', (ws, req) => {
    const clientId = uuid();
    clients.set(clientId, ws);
    console.log(`WS client connected: ${clientId}`);

    ws.send(JSON.stringify({ type: 'connected', clientId, timestamp: new Date().toISOString() }));

    ws.on('message', async (raw) => {
      let msg;
      try {
        msg = JSON.parse(raw.toString());
      } catch {
        ws.send(JSON.stringify({ type: 'error', message: 'Invalid JSON' }));
        return;
      }

      try {
        await handleMessage(ws, msg);
      } catch (err) {
        ws.send(JSON.stringify({ type: 'error', message: err.message }));
      }
    });

    ws.on('close', () => {
      clients.delete(clientId);
      console.log(`WS client disconnected: ${clientId}`);
    });

    ws.on('error', (err) => {
      console.error('WS error:', err.message);
      clients.delete(clientId);
    });
  });
}

async function handleMessage(ws, msg) {
  const { type, id } = msg;

  switch (type) {
    case 'chat': {
      const { provider, model, messages, systemPrompt, agentId } = msg;
      ws.send(JSON.stringify({ type: 'chat_start', id }));

      let fullText = '';
      try {
        for await (const chunk of streamChat({ provider, model, messages, systemPrompt })) {
          fullText += chunk;
          ws.send(JSON.stringify({ type: 'chat_chunk', id, chunk }));
        }
        ws.send(JSON.stringify({ type: 'chat_end', id, fullText }));
      } catch (err) {
        ws.send(JSON.stringify({ type: 'chat_error', id, message: err.message }));
      }
      break;
    }

    case 'agent_run': {
      const { agentId, message } = msg;
      const agent = agentManager.get(agentId);
      if (!agent) {
        ws.send(JSON.stringify({ type: 'error', message: 'Agent not found: ' + agentId }));
        return;
      }

      ws.send(JSON.stringify({ type: 'agent_start', id, agentId, agentName: agent.name }));

      try {
        await agent.run(message, (chunk) => {
          ws.send(JSON.stringify({ type: 'agent_chunk', id, agentId, chunk }));
        });
        ws.send(JSON.stringify({ type: 'agent_end', id, agentId, stats: agent.stats }));
      } catch (err) {
        ws.send(JSON.stringify({ type: 'agent_error', id, agentId, message: err.message }));
      }
      break;
    }

    case 'ping':
      ws.send(JSON.stringify({ type: 'pong', timestamp: new Date().toISOString() }));
      break;

    default:
      ws.send(JSON.stringify({ type: 'error', message: 'Unknown message type: ' + type }));
  }
}

export function broadcast(data) {
  const payload = JSON.stringify(data);
  clients.forEach(ws => {
    if (ws.readyState === 1) ws.send(payload);
  });
}

export function getClientCount() {
  return clients.size;
}

export const MODEL_REGISTRY = {
  openai: {
    name: 'OpenAI',
    color: '#10a37f',
    models: [
      { id: 'gpt-4o', name: 'GPT-4o', context: 128000, vision: true },
      { id: 'gpt-4o-mini', name: 'GPT-4o Mini', context: 128000, vision: true },
      { id: 'gpt-3.5-turbo', name: 'GPT-3.5 Turbo', context: 16385 },
    ],
  },
  anthropic: {
    name: 'Anthropic',
    color: '#d97757',
    models: [
      { id: 'claude-opus-4-6', name: 'Claude Opus 4.6', context: 200000, vision: true },
      { id: 'claude-sonnet-4-6', name: 'Claude Sonnet 4.6', context: 200000, vision: true },
      { id: 'claude-haiku-4-5-20251001', name: 'Claude Haiku 4.5', context: 200000 },
    ],
  },
  gemini: {
    name: 'Google Gemini',
    color: '#4285f4',
    models: [
      { id: 'gemini-1.5-pro', name: 'Gemini 1.5 Pro', context: 1000000, vision: true },
      { id: 'gemini-1.5-flash', name: 'Gemini 1.5 Flash', context: 1000000, vision: true },
    ],
  },
};

export function getDefaultModel(provider) {
  const p = MODEL_REGISTRY[provider];
  if (!p) throw new Error('Unknown provider: ' + provider);
  return p.models[0];
}

export function listAllModels() {
  return Object.entries(MODEL_REGISTRY).flatMap(([provider, info]) =>
    info.models.map(m => ({ ...m, provider, providerName: info.name, color: info.color }))
  );
}

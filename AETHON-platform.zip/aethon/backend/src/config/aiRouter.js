import OpenAI from 'openai';
import Anthropic from '@anthropic-ai/sdk';
import { GoogleGenerativeAI } from '@google/generative-ai';
import dotenv from 'dotenv';
dotenv.config();

// Lazy-initialize clients
let _openai, _anthropic, _gemini;

function getOpenAI() {
  if (!_openai) _openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  return _openai;
}
function getAnthropic() {
  if (!_anthropic) _anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
  return _anthropic;
}
function getGemini() {
  if (!_gemini) _gemini = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
  return _gemini;
}

/**
 * Route a chat request to the correct provider.
 * Returns an async generator of text chunks.
 */
export async function* streamChat({ provider, model, messages, systemPrompt, temperature = 0.7 }) {
  switch (provider) {
    case 'openai':
      yield* streamOpenAI({ model, messages, systemPrompt, temperature });
      break;
    case 'anthropic':
      yield* streamAnthropic({ model, messages, systemPrompt, temperature });
      break;
    case 'gemini':
      yield* streamGemini({ model, messages, systemPrompt, temperature });
      break;
    default:
      throw new Error('Unknown provider: ' + provider);
  }
}

async function* streamOpenAI({ model, messages, systemPrompt, temperature }) {
  const msgs = [];
  if (systemPrompt) msgs.push({ role: 'system', content: systemPrompt });
  msgs.push(...messages);

  const stream = await getOpenAI().chat.completions.create({
    model,
    messages: msgs,
    temperature,
    stream: true,
  });

  for await (const chunk of stream) {
    const text = chunk.choices[0]?.delta?.content;
    if (text) yield text;
  }
}

async function* streamAnthropic({ model, messages, systemPrompt, temperature }) {
  const stream = await getAnthropic().messages.stream({
    model,
    max_tokens: 8096,
    system: systemPrompt,
    messages,
    temperature,
  });

  for await (const chunk of stream) {
    if (chunk.type === 'content_block_delta' && chunk.delta?.type === 'text_delta') {
      yield chunk.delta.text;
    }
  }
}

async function* streamGemini({ model, messages, systemPrompt, temperature }) {
  const genModel = getGemini().getGenerativeModel({
    model,
    generationConfig: { temperature },
    systemInstruction: systemPrompt,
  });

  // Convert messages to Gemini format
  const history = messages.slice(0, -1).map(m => ({
    role: m.role === 'assistant' ? 'model' : 'user',
    parts: [{ text: m.content }],
  }));
  const lastMsg = messages[messages.length - 1];

  const chat = genModel.startChat({ history });
  const result = await chat.sendMessageStream(lastMsg.content);

  for await (const chunk of result.stream) {
    const text = chunk.text();
    if (text) yield text;
  }
}

/**
 * Non-streaming chat — returns full response string
 */
export async function chat({ provider, model, messages, systemPrompt, temperature = 0.7 }) {
  let result = '';
  for await (const chunk of streamChat({ provider, model, messages, systemPrompt, temperature })) {
    result += chunk;
  }
  return result;
}

import { Router } from 'express';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);
const router = Router();

// Whitelist safe commands
const ALLOWED_COMMANDS = new Set([
  'ls', 'pwd', 'echo', 'date', 'whoami', 'uname', 'cat',
  'head', 'tail', 'wc', 'grep', 'find', 'ps', 'df', 'du',
  'node', 'npm', 'python3', 'git',
]);

function isSafeCommand(cmd) {
  const base = cmd.trim().split(/\s+/)[0];
  return ALLOWED_COMMANDS.has(base);
}

router.post('/execute', async (req, res) => {
  const { command, cwd } = req.body;
  if (!command) return res.status(400).json({ error: 'command required' });

  if (!isSafeCommand(command)) {
    return res.status(403).json({ error: 'Command not allowed for security reasons', command });
  }

  try {
    const { stdout, stderr } = await execAsync(command, {
      timeout: 10000,
      cwd: cwd || process.cwd(),
    });
    res.json({ stdout, stderr, exitCode: 0, command });
  } catch (err) {
    res.json({ stdout: '', stderr: err.message, exitCode: err.code || 1, command });
  }
});

router.get('/allowed', (req, res) => {
  res.json({ commands: Array.from(ALLOWED_COMMANDS) });
});

export default router;

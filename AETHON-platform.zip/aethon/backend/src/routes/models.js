import { Router } from 'express';
import { MODEL_REGISTRY, listAllModels } from '../config/models.js';

const router = Router();

router.get('/', (req, res) => res.json(MODEL_REGISTRY));
router.get('/all', (req, res) => res.json(listAllModels()));
router.get('/:provider', (req, res) => {
  const p = MODEL_REGISTRY[req.params.provider];
  if (!p) return res.status(404).json({ error: 'Provider not found' });
  res.json(p);
});

export default router;

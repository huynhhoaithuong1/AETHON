import { Router } from 'express';
import { streamChat, chat } from '../config/aiRouter.js';

const router = Router();

// POST /api/chat/stream — SSE streaming
router.post('/stream', async (req, res) => {
  const { provider = 'openai', model = 'gpt-4o', messages, systemPrompt, temperature } = req.body;
  if (!messages?.length) return res.status(400).json({ error: 'messages required' });

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();

  try {
    for await (const chunk of streamChat({ provider, model, messages, systemPrompt, temperature })) {
      res.write(`data: ${JSON.stringify({ chunk })}\n\n`);
    }
    res.write('data: [DONE]\n\n');
  } catch (err) {
    res.write(`data: ${JSON.stringify({ error: err.message })}\n\n`);
  } finally {
    res.end();
  }
});

// POST /api/chat — non-streaming
router.post('/', async (req, res) => {
  const { provider = 'openai', model = 'gpt-4o', messages, systemPrompt, temperature } = req.body;
  if (!messages?.length) return res.status(400).json({ error: 'messages required' });
  try {
    const response = await chat({ provider, model, messages, systemPrompt, temperature });
    res.json({ response, provider, model });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;

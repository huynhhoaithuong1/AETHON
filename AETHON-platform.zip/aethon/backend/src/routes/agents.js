import { Router } from 'express';
import { agentManager } from '../index.js';

const router = Router();

router.get('/', (req, res) => res.json(agentManager.list()));

router.post('/', (req, res) => {
  const agent = agentManager.create(req.body);
  res.status(201).json(agent.toJSON());
});

router.get('/:id', (req, res) => {
  const agent = agentManager.get(req.params.id);
  if (!agent) return res.status(404).json({ error: 'Agent not found' });
  res.json(agent.toJSON());
});

router.delete('/:id', (req, res) => {
  const ok = agentManager.delete(req.params.id);
  if (!ok) return res.status(404).json({ error: 'Agent not found' });
  res.json({ success: true });
});

router.post('/:id/run', async (req, res) => {
  const agent = agentManager.get(req.params.id);
  if (!agent) return res.status(404).json({ error: 'Agent not found' });
  const { message } = req.body;
  if (!message) return res.status(400).json({ error: 'message required' });

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.flushHeaders();

  try {
    await agent.run(message, (chunk) => {
      res.write(`data: ${JSON.stringify({ chunk })}\n\n`);
    });
    res.write('data: [DONE]\n\n');
  } catch (err) {
    res.write(`data: ${JSON.stringify({ error: err.message })}\n\n`);
  } finally {
    res.end();
  }
});

router.post('/:id/clear', (req, res) => {
  const agent = agentManager.get(req.params.id);
  if (!agent) return res.status(404).json({ error: 'Agent not found' });
  agent.clearMemory();
  res.json({ success: true });
});

export default router;

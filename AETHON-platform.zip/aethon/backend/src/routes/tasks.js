import { Router } from 'express';
import { v4 as uuid } from 'uuid';

const router = Router();
const tasks = new Map();

router.get('/', (req, res) => res.json(Array.from(tasks.values())));

router.post('/', (req, res) => {
  const { name, description, agentId, priority = 'normal' } = req.body;
  const task = {
    id: uuid(), name, description, agentId, priority,
    status: 'pending',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    result: null,
  };
  tasks.set(task.id, task);
  res.status(201).json(task);
});

router.get('/:id', (req, res) => {
  const task = tasks.get(req.params.id);
  if (!task) return res.status(404).json({ error: 'Task not found' });
  res.json(task);
});

router.patch('/:id', (req, res) => {
  const task = tasks.get(req.params.id);
  if (!task) return res.status(404).json({ error: 'Task not found' });
  Object.assign(task, req.body, { updatedAt: new Date().toISOString() });
  res.json(task);
});

router.delete('/:id', (req, res) => {
  tasks.delete(req.params.id);
  res.json({ success: true });
});

export default router;

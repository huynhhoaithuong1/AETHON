import { Router } from 'express';

const router = Router();

const BUILTIN_TOOLS = [
  { id: 'web_search', name: 'Web Search', description: 'Search the internet', category: 'search', enabled: true },
  { id: 'code_exec', name: 'Code Executor', description: 'Execute code snippets', category: 'compute', enabled: true },
  { id: 'file_read', name: 'File Reader', description: 'Read and analyze files', category: 'filesystem', enabled: true },
  { id: 'calculator', name: 'Calculator', description: 'Math and computation', category: 'utility', enabled: true },
  { id: 'summarizer', name: 'Summarizer', description: 'Summarize long content', category: 'ai', enabled: true },
];

router.get('/', (req, res) => res.json(BUILTIN_TOOLS));

router.post('/execute', async (req, res) => {
  const { toolId, params } = req.body;
  const tool = BUILTIN_TOOLS.find(t => t.id === toolId);
  if (!tool) return res.status(404).json({ error: 'Tool not found' });
  if (!tool.enabled) return res.status(400).json({ error: 'Tool disabled' });

  // Simulated execution — extend with real implementations
  await new Promise(r => setTimeout(r, 300));
  res.json({
    toolId,
    result: `[${tool.name}] executed with params: ${JSON.stringify(params)}`,
    timestamp: new Date().toISOString(),
  });
});

export default router;

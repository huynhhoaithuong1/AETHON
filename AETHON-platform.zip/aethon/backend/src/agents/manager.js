import { v4 as uuid } from 'uuid';
import { chat } from '../config/aiRouter.js';

const AGENT_SYSTEM_PROMPT = `You are AETHON, an advanced AI agent. You can:
- Analyze and reason about complex problems
- Execute tasks step by step
- Use tools when needed
- Remember context from your conversation

Always be concise, accurate, and helpful. When executing tasks, think step-by-step.`;

export class Agent {
  constructor({ name, description, provider = 'openai', model = 'gpt-4o', systemPrompt }) {
    this.id = uuid();
    this.name = name || 'AETHON Agent';
    this.description = description || 'General purpose AI agent';
    this.provider = provider;
    this.model = model;
    this.systemPrompt = systemPrompt || AGENT_SYSTEM_PROMPT;
    this.status = 'idle'; // idle | running | paused | error
    this.memory = []; // conversation history
    this.tasks = [];
    this.createdAt = new Date().toISOString();
    this.updatedAt = new Date().toISOString();
    this.stats = { messages: 0, tasks: 0, tokens: 0 };
  }

  async run(userMessage, onChunk) {
    this.status = 'running';
    this.updatedAt = new Date().toISOString();

    this.memory.push({ role: 'user', content: userMessage });

    let response = '';
    try {
      const { streamChat } = await import('../config/aiRouter.js');
      for await (const chunk of streamChat({
        provider: this.provider,
        model: this.model,
        messages: this.memory,
        systemPrompt: this.systemPrompt,
      })) {
        response += chunk;
        if (onChunk) onChunk(chunk);
      }

      this.memory.push({ role: 'assistant', content: response });
      this.stats.messages++;
      this.status = 'idle';
      return response;
    } catch (err) {
      this.status = 'error';
      throw err;
    }
  }

  clearMemory() {
    this.memory = [];
  }

  toJSON() {
    return {
      id: this.id,
      name: this.name,
      description: this.description,
      provider: this.provider,
      model: this.model,
      status: this.status,
      memoryLength: this.memory.length,
      createdAt: this.createdAt,
      updatedAt: this.updatedAt,
      stats: this.stats,
    };
  }
}

export class AgentManager {
  constructor() {
    this.agents = new Map();
    this._seedDefaults();
  }

  _seedDefaults() {
    const defaults = [
      {
        name: 'Commander',
        description: 'Primary orchestration agent — delegates tasks to specialists',
        provider: process.env.DEFAULT_PROVIDER || 'openai',
        model: process.env.DEFAULT_MODEL || 'gpt-4o',
      },
      {
        name: 'Analyst',
        description: 'Deep analysis and research agent',
        provider: 'anthropic',
        model: 'claude-sonnet-4-6',
      },
      {
        name: 'Coder',
        description: 'Code generation, review, and debugging',
        provider: 'openai',
        model: 'gpt-4o',
        systemPrompt: 'You are an expert software engineer. Write clean, well-commented code. Always explain your implementation.',
      },
    ];
    defaults.forEach(d => {
      const a = new Agent(d);
      this.agents.set(a.id, a);
    });
  }

  create(config) {
    const agent = new Agent(config);
    this.agents.set(agent.id, agent);
    return agent;
  }

  get(id) {
    return this.agents.get(id);
  }

  list() {
    return Array.from(this.agents.values()).map(a => a.toJSON());
  }

  delete(id) {
    return this.agents.delete(id);
  }

  getStats() {
    const agents = Array.from(this.agents.values());
    return {
      total: agents.length,
      running: agents.filter(a => a.status === 'running').length,
      idle: agents.filter(a => a.status === 'idle').length,
      error: agents.filter(a => a.status === 'error').length,
    };
  }
}

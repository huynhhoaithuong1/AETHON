# ⚡ AETHON — AI Agent Platform

A production-ready multi-model AI platform with agents, real-time chat, terminal, and a sleek dashboard. Supports **OpenAI**, **Anthropic (Claude)**, and **Google Gemini** with hot-swappable routing.

---

## Architecture

```
aethon/
├── backend/                   # Node.js + Express API
│   └── src/
│       ├── index.js           # Server entrypoint
│       ├── config/
│       │   ├── models.js      # Model registry (all providers)
│       │   └── aiRouter.js    # Multi-provider streaming router
│       ├── agents/
│       │   └── manager.js     # Agent lifecycle management
│       ├── routes/
│       │   ├── chat.js        # POST /api/chat (stream + sync)
│       │   ├── agents.js      # CRUD + run agents
│       │   ├── tasks.js       # Task queue
│       │   ├── tools.js       # Tool registry + executor
│       │   ├── terminal.js    # Safe command execution
│       │   └── models.js      # Model listing
│       └── websocket/
│           └── handler.js     # Real-time WS (chat, agents)
│
├── frontend/                  # Next.js 14 App Router
│   └── app/
│       ├── (platform)/
│       │   ├── layout.tsx     # Sidebar shell
│       │   ├── dashboard/     # System overview
│       │   ├── chat/          # Streaming multi-model chat
│       │   ├── terminal/      # Command execution UI
│       │   ├── agents/        # Agent management + chat
│       │   └── tools/         # Tool registry + executor
│       ├── lib/api.ts         # API + SSE client
│       └── hooks/
│           ├── useWebSocket.ts
│           └── useSystemStatus.ts
│
└── package.json               # Monorepo runner
```

---

## Quick Start

### 1. Install dependencies

```bash
cd aethon
npm run install:all
```

### 2. Configure API keys

```bash
# Backend
cp backend/.env.example backend/.env

# Edit backend/.env and fill in your keys:
# OPENAI_API_KEY=sk-...
# ANTHROPIC_API_KEY=sk-ant-...
# GEMINI_API_KEY=AIza...

# Frontend
cp frontend/.env.local.example frontend/.env.local
```

### 3. Run in development

```bash
npm run dev
```

This starts both:
- **Backend** → http://localhost:3001
- **Frontend** → http://localhost:3000

---

## API Reference

### Chat

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/chat` | Non-streaming chat |
| POST | `/api/chat/stream` | SSE streaming chat |

**Request body:**
```json
{
  "provider": "openai",
  "model": "gpt-4o",
  "messages": [{ "role": "user", "content": "Hello!" }],
  "systemPrompt": "You are a helpful assistant.",
  "temperature": 0.7
}
```

### Agents

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/agents` | List all agents |
| POST | `/api/agents` | Create agent |
| GET | `/api/agents/:id` | Get agent |
| DELETE | `/api/agents/:id` | Delete agent |
| POST | `/api/agents/:id/run` | Run agent (SSE stream) |
| POST | `/api/agents/:id/clear` | Clear agent memory |

### Terminal

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/terminal/execute` | Execute safe command |
| GET | `/api/terminal/allowed` | List allowed commands |

### WebSocket

Connect to `ws://localhost:3001/ws`

**Send:**
```json
{ "type": "chat", "id": "uuid", "provider": "openai", "model": "gpt-4o", "messages": [...] }
{ "type": "agent_run", "id": "uuid", "agentId": "agent-uuid", "message": "Do a task" }
```

**Receive:**
```json
{ "type": "chat_chunk", "id": "uuid", "chunk": "Hello" }
{ "type": "chat_end", "id": "uuid", "fullText": "Hello world!" }
{ "type": "agent_chunk", "id": "uuid", "agentId": "...", "chunk": "..." }
```

---

## Supported Models

### OpenAI
- `gpt-4o` — Latest flagship
- `gpt-4o-mini` — Fast and efficient
- `gpt-3.5-turbo` — Classic

### Anthropic
- `claude-opus-4-6` — Most powerful
- `claude-sonnet-4-6` — Balanced
- `claude-haiku-4-5-20251001` — Fast

### Google Gemini
- `gemini-1.5-pro` — 1M context
- `gemini-1.5-flash` — Fast multimodal

---

## Extending AETHON

### Add a new AI provider

Edit `backend/src/config/aiRouter.js` and add a new `async function* stream<ProviderName>()` generator, then register it in the `streamChat` switch.

### Add a new tool

Edit `backend/src/routes/tools.js` — add to `BUILTIN_TOOLS` and implement execution logic in the `/execute` handler.

### Add a new page

Create `frontend/app/(platform)/<page>/page.tsx` and add it to the `NAV` array in `frontend/app/(platform)/layout.tsx`.

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Backend | Node.js 18+, Express 4, WebSocket (ws) |
| Frontend | Next.js 14, React 18, TypeScript |
| Styling | Tailwind CSS, custom design system |
| AI | OpenAI SDK, Anthropic SDK, Google Generative AI |
| State | React hooks (no Redux needed) |
| Fonts | Syne (display), Space Grotesk, JetBrains Mono |

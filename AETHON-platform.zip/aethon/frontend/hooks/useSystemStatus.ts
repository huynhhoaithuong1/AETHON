'use client';
import { useState, useEffect } from 'react';

export function useSystemStatus() {
  const [status, setStatus] = useState<'connecting' | 'online' | 'offline'>('connecting');
  const [data, setData] = useState<any>(null);

  useEffect(() => {
    const check = async () => {
      try {
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001'}/health`);
        if (res.ok) {
          const d = await res.json();
          setData(d);
          setStatus('online');
        } else {
          setStatus('offline');
        }
      } catch {
        setStatus('offline');
      }
    };

    check();
    const interval = setInterval(check, 15000);
    return () => clearInterval(interval);
  }, []);

  return { status, data };
}

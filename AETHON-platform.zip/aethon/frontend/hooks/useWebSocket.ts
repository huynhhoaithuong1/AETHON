'use client';
import { useEffect, useRef, useState, useCallback } from 'react';
import { v4 as uuid } from 'uuid';

type Handler = (msg: any) => void;

export function useWebSocket() {
  const ws = useRef<WebSocket | null>(null);
  const handlers = useRef<Map<string, Handler>>(new Map());
  const [connected, setConnected] = useState(false);
  const reconnectTimer = useRef<NodeJS.Timeout>();

  const connect = useCallback(() => {
    const url = process.env.NEXT_PUBLIC_WS_URL || 'ws://localhost:3001/ws';
    ws.current = new WebSocket(url);

    ws.current.onopen = () => {
      setConnected(true);
      console.log('WS connected');
    };

    ws.current.onclose = () => {
      setConnected(false);
      reconnectTimer.current = setTimeout(connect, 3000);
    };

    ws.current.onerror = () => {
      ws.current?.close();
    };

    ws.current.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data);
        handlers.current.forEach(handler => handler(msg));
      } catch {}
    };
  }, []);

  useEffect(() => {
    connect();
    return () => {
      clearTimeout(reconnectTimer.current);
      ws.current?.close();
    };
  }, [connect]);

  const send = useCallback((data: any) => {
    if (ws.current?.readyState === WebSocket.OPEN) {
      ws.current.send(JSON.stringify(data));
    }
  }, []);

  const on = useCallback((handler: Handler) => {
    const id = uuid();
    handlers.current.set(id, handler);
    return () => handlers.current.delete(id);
  }, []);

  const streamChat = useCallback((payload: any, onChunk: (c: string) => void, onDone?: (full: string) => void) => {
    const id = uuid();
    let full = '';

    const off = on((msg) => {
      if (msg.id !== id) return;
      if (msg.type === 'chat_chunk') { full += msg.chunk; onChunk(msg.chunk); }
      if (msg.type === 'chat_end') { off(); onDone?.(full); }
      if (msg.type === 'chat_error') { off(); throw new Error(msg.message); }
    });

    send({ type: 'chat', id, ...payload });
    return () => off();
  }, [on, send]);

  return { connected, send, on, streamChat };
}

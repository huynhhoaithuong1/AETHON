const BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';

async function request(path: string, options?: RequestInit) {
  const res = await fetch(`${BASE}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(err.error || `HTTP ${res.status}`);
  }
  return res.json();
}

export const api = {
  // Health
  health: () => request('/health'),

  // Models
  models: {
    all: () => request('/api/models/all'),
    byProvider: (provider: string) => request(`/api/models/${provider}`),
  },

  // Chat
  chat: {
    send: (payload: ChatPayload) =>
      request('/api/chat', { method: 'POST', body: JSON.stringify(payload) }),
  },

  // Agents
  agents: {
    list: () => request('/api/agents'),
    create: (data: any) => request('/api/agents', { method: 'POST', body: JSON.stringify(data) }),
    get: (id: string) => request(`/api/agents/${id}`),
    delete: (id: string) => request(`/api/agents/${id}`, { method: 'DELETE' }),
    clearMemory: (id: string) => request(`/api/agents/${id}/clear`, { method: 'POST' }),
  },

  // Tasks
  tasks: {
    list: () => request('/api/tasks'),
    create: (data: any) => request('/api/tasks', { method: 'POST', body: JSON.stringify(data) }),
    update: (id: string, data: any) => request(`/api/tasks/${id}`, { method: 'PATCH', body: JSON.stringify(data) }),
    delete: (id: string) => request(`/api/tasks/${id}`, { method: 'DELETE' }),
  },

  // Tools
  tools: {
    list: () => request('/api/tools'),
    execute: (toolId: string, params: any) =>
      request('/api/tools/execute', { method: 'POST', body: JSON.stringify({ toolId, params }) }),
  },

  // Terminal
  terminal: {
    execute: (command: string, cwd?: string) =>
      request('/api/terminal/execute', { method: 'POST', body: JSON.stringify({ command, cwd }) }),
    allowed: () => request('/api/terminal/allowed'),
  },
};

export interface ChatPayload {
  provider: string;
  model: string;
  messages: { role: string; content: string }[];
  systemPrompt?: string;
  temperature?: number;
}

/**
 * Stream a chat response via SSE
 */
export async function streamChat(
  payload: ChatPayload,
  onChunk: (chunk: string) => void,
  onDone?: (full: string) => void
) {
  const res = await fetch(`${BASE}/api/chat/stream`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });

  if (!res.ok) throw new Error(`Stream error: ${res.status}`);

  const reader = res.body!.getReader();
  const decoder = new TextDecoder();
  let full = '';
  let buffer = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n');
    buffer = lines.pop() || '';

    for (const line of lines) {
      if (!line.startsWith('data: ')) continue;
      const data = line.slice(6).trim();
      if (data === '[DONE]') {
        onDone?.(full);
        return full;
      }
      try {
        const parsed = JSON.parse(data);
        if (parsed.chunk) {
          full += parsed.chunk;
          onChunk(parsed.chunk);
        }
        if (parsed.error) throw new Error(parsed.error);
      } catch {}
    }
  }

  onDone?.(full);
  return full;
}

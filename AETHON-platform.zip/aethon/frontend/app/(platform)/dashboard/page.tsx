'use client';
import { useState, useEffect } from 'react';
import {
  Bot, Zap, Terminal, MessageSquare, Activity, Clock,
  TrendingUp, Cpu, Globe, ChevronRight, Circle
} from 'lucide-react';
import Link from 'next/link';
import { api } from '../../../lib/api';

interface StatCard {
  label: string;
  value: string | number;
  sub?: string;
  icon: any;
  color: string;
  href?: string;
}

export default function DashboardPage() {
  const [health, setHealth] = useState<any>(null);
  const [agents, setAgents] = useState<any[]>([]);
  const [models, setModels] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const [h, a, m] = await Promise.all([
          api.health().catch(() => null),
          api.agents.list().catch(() => []),
          api.models.all().catch(() => []),
        ]);
        setHealth(h);
        setAgents(a);
        setModels(m);
      } finally {
        setLoading(false);
      }
    };
    load();
    const interval = setInterval(load, 10000);
    return () => clearInterval(interval);
  }, []);

  const stats: StatCard[] = [
    {
      label: 'Active Agents',
      value: health?.agents?.total ?? agents.length,
      sub: `${health?.agents?.running ?? 0} running`,
      icon: Bot,
      color: 'accent',
      href: '/agents',
    },
    {
      label: 'AI Models',
      value: models.length || 8,
      sub: '3 providers',
      icon: Cpu,
      color: 'accent2',
    },
    {
      label: 'System Status',
      value: health ? 'Online' : 'Offline',
      sub: health?.timestamp ? new Date(health.timestamp).toLocaleTimeString() : '—',
      icon: Activity,
      color: health ? 'success' : 'error',
    },
    {
      label: 'Platform',
      value: 'v1.0.0',
      sub: 'AETHON Core',
      icon: Zap,
      color: 'accent3',
    },
  ];

  return (
    <div className="h-full overflow-y-auto p-6">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-2 text-aethon-muted text-xs mb-2 font-mono">
          <Circle size={6} className="fill-aethon-accent text-aethon-accent" />
          <span className="tracking-widest uppercase">System Overview</span>
        </div>
        <h1 className="font-display font-bold text-3xl text-white">
          Mission <span className="text-aethon-accent">Control</span>
        </h1>
        <p className="text-aethon-muted text-sm mt-1">
          Multi-model AI platform — OpenAI · Anthropic · Gemini
        </p>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4 mb-8">
        {stats.map((stat, i) => {
          const Icon = stat.icon;
          const colorMap: Record<string, string> = {
            accent: '#00d4ff',
            accent2: '#7c3aed',
            accent3: '#f59e0b',
            success: '#10b981',
            error: '#ef4444',
          };
          const color = colorMap[stat.color] || '#00d4ff';
          const card = (
            <div
              key={i}
              className="bg-aethon-surface border border-aethon-border rounded-xl p-4 hover:border-opacity-60 transition-all group cursor-pointer"
              style={{ '--hover-color': color } as any}
            >
              <div className="flex items-start justify-between mb-3">
                <div
                  className="w-9 h-9 rounded-lg flex items-center justify-center"
                  style={{ background: `${color}15`, border: `1px solid ${color}30` }}
                >
                  <Icon size={16} style={{ color }} />
                </div>
                {stat.href && (
                  <ChevronRight size={14} className="text-aethon-border group-hover:text-aethon-muted transition-colors" />
                )}
              </div>
              <div className="text-2xl font-display font-bold text-white mb-0.5">{stat.value}</div>
              <div className="text-xs text-aethon-muted">{stat.label}</div>
              {stat.sub && <div className="text-[10px] text-aethon-muted/60 mt-0.5 font-mono">{stat.sub}</div>}
            </div>
          );
          return stat.href ? <Link href={stat.href} key={i}>{card}</Link> : card;
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Agents panel */}
        <div className="lg:col-span-2 bg-aethon-surface border border-aethon-border rounded-xl p-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Bot size={14} className="text-aethon-accent" />
              <span className="font-semibold text-sm text-white">Active Agents</span>
            </div>
            <Link href="/agents" className="text-xs text-aethon-accent hover:underline">View all →</Link>
          </div>
          <div className="space-y-2">
            {loading ? (
              [...Array(3)].map((_, i) => (
                <div key={i} className="h-12 rounded-lg shimmer" />
              ))
            ) : agents.slice(0, 5).map((agent) => (
              <div key={agent.id} className="flex items-center gap-3 p-3 bg-aethon-bg rounded-lg border border-aethon-border/50 hover:border-aethon-accent/20 transition-all">
                <div className={`status-dot ${agent.status}`} />
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-white truncate">{agent.name}</div>
                  <div className="text-xs text-aethon-muted truncate">{agent.description}</div>
                </div>
                <div className="text-right shrink-0">
                  <div className="text-xs font-mono text-aethon-muted">{agent.provider}</div>
                  <div className="text-[10px] text-aethon-muted/60">{agent.model?.split('-').slice(0,2).join('-')}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick actions */}
        <div className="bg-aethon-surface border border-aethon-border rounded-xl p-4">
          <div className="flex items-center gap-2 mb-4">
            <Zap size={14} className="text-aethon-accent3" />
            <span className="font-semibold text-sm text-white">Quick Launch</span>
          </div>
          <div className="space-y-2">
            {[
              { label: 'New Chat', icon: MessageSquare, href: '/chat', color: '#00d4ff' },
              { label: 'Open Terminal', icon: Terminal, href: '/terminal', color: '#10b981' },
              { label: 'Manage Agents', icon: Bot, href: '/agents', color: '#7c3aed' },
            ].map(({ label, icon: Icon, href, color }) => (
              <Link
                key={href}
                href={href}
                className="flex items-center gap-3 p-3 rounded-lg border border-aethon-border hover:border-opacity-60 transition-all group"
                style={{ '--c': color } as any}
              >
                <div className="w-8 h-8 rounded-md flex items-center justify-center" style={{ background: `${color}15` }}>
                  <Icon size={14} style={{ color }} />
                </div>
                <span className="text-sm text-aethon-muted group-hover:text-white transition-colors">{label}</span>
                <ChevronRight size={12} className="ml-auto text-aethon-border group-hover:text-aethon-muted transition-colors" />
              </Link>
            ))}
          </div>

          {/* Provider status */}
          <div className="mt-4 pt-4 border-t border-aethon-border">
            <div className="text-xs text-aethon-muted mb-3 uppercase tracking-wider font-mono">AI Providers</div>
            <div className="space-y-1.5">
              {[
                { name: 'OpenAI', color: '#10a37f' },
                { name: 'Anthropic', color: '#d97757' },
                { name: 'Gemini', color: '#4285f4' },
              ].map(({ name, color }) => (
                <div key={name} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full" style={{ background: color, boxShadow: `0 0 4px ${color}` }} />
                    <span className="text-xs text-aethon-muted">{name}</span>
                  </div>
                  <span className="text-[10px] text-aethon-success font-mono">ready</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

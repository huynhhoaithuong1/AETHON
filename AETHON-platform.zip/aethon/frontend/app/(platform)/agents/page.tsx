'use client';
import { useState, useEffect, useCallback } from 'react';
import { Plus, Bot, Trash2, MessageSquare, Cpu, RefreshCw, Circle, X, Loader, ChevronRight } from 'lucide-react';
import { api } from '../../../lib/api';
import { streamChat } from '../../../lib/api';

const PROVIDER_COLORS: Record<string, string> = {
  openai: '#10a37f',
  anthropic: '#d97757',
  gemini: '#4285f4',
};

const STATUS_LABELS: Record<string, string> = {
  idle: 'Idle',
  running: 'Running',
  error: 'Error',
  paused: 'Paused',
};

export default function AgentsPage() {
  const [agents, setAgents] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<any | null>(null);
  const [chatInput, setChatInput] = useState('');
  const [chatHistory, setChatHistory] = useState<{role:string,content:string}[]>([]);
  const [streaming, setStreaming] = useState(false);
  const [showCreate, setShowCreate] = useState(false);
  const [creating, setCreating] = useState(false);
  const [newAgent, setNewAgent] = useState({
    name: '',
    description: '',
    provider: 'openai',
    model: 'gpt-4o',
    systemPrompt: '',
  });

  const load = useCallback(async () => {
    try {
      const data = await api.agents.list();
      setAgents(data);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const createAgent = async () => {
    if (!newAgent.name) return;
    setCreating(true);
    try {
      await api.agents.create(newAgent);
      setShowCreate(false);
      setNewAgent({ name: '', description: '', provider: 'openai', model: 'gpt-4o', systemPrompt: '' });
      await load();
    } finally {
      setCreating(false);
    }
  };

  const deleteAgent = async (id: string) => {
    await api.agents.delete(id);
    if (selected?.id === id) setSelected(null);
    await load();
  };

  const clearAgentMemory = async (id: string) => {
    await api.agents.clearMemory(id);
    setChatHistory([]);
  };

  const sendToAgent = async () => {
    if (!selected || !chatInput.trim() || streaming) return;
    const text = chatInput.trim();
    setChatInput('');
    setStreaming(true);
    setChatHistory(prev => [...prev, { role: 'user', content: text }]);

    const allMsgs = [...chatHistory, { role: 'user', content: text }];
    let response = '';
    const tempId = crypto.randomUUID();
    setChatHistory(prev => [...prev, { role: 'assistant', content: '' }]);

    try {
      await streamChat(
        { provider: selected.provider, model: selected.model, messages: allMsgs },
        (chunk) => {
          response += chunk;
          setChatHistory(prev => {
            const updated = [...prev];
            updated[updated.length - 1] = { role: 'assistant', content: response };
            return updated;
          });
        }
      );
    } catch (err: any) {
      setChatHistory(prev => {
        const updated = [...prev];
        updated[updated.length - 1] = { role: 'assistant', content: `Error: ${err.message}` };
        return updated;
      });
    } finally {
      setStreaming(false);
    }
  };

  return (
    <div className="h-full flex overflow-hidden">
      {/* Agents list */}
      <div className="w-72 flex flex-col border-r border-aethon-border bg-aethon-surface/30 shrink-0">
        <div className="flex items-center justify-between px-4 py-3 border-b border-aethon-border">
          <div className="flex items-center gap-2">
            <Circle size={6} className="fill-aethon-accent text-aethon-accent" />
            <span className="font-display font-semibold text-white text-sm">Agents</span>
            <span className="text-xs text-aethon-muted font-mono">({agents.length})</span>
          </div>
          <div className="flex gap-1">
            <button onClick={load} className="p-1.5 text-aethon-muted hover:text-white transition-colors">
              <RefreshCw size={13} />
            </button>
            <button
              onClick={() => setShowCreate(true)}
              className="p-1.5 rounded bg-aethon-accent/20 text-aethon-accent hover:bg-aethon-accent/30 transition-colors"
            >
              <Plus size={13} />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {loading ? (
            [...Array(3)].map((_, i) => <div key={i} className="h-16 rounded-lg shimmer" />)
          ) : agents.map((agent) => {
            const color = PROVIDER_COLORS[agent.provider] || '#64748b';
            const isSelected = selected?.id === agent.id;
            return (
              <div
                key={agent.id}
                onClick={() => { setSelected(agent); setChatHistory([]); }}
                className={`p-3 rounded-lg cursor-pointer transition-all border group ${
                  isSelected
                    ? 'bg-aethon-accent/10 border-aethon-accent/30'
                    : 'bg-transparent border-transparent hover:bg-aethon-surface hover:border-aethon-border'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <div className={`status-dot ${agent.status}`} />
                    <span className="font-medium text-sm text-white truncate">{agent.name}</span>
                  </div>
                  <button
                    onClick={(e) => { e.stopPropagation(); deleteAgent(agent.id); }}
                    className="opacity-0 group-hover:opacity-100 p-0.5 text-aethon-muted hover:text-aethon-error transition-all shrink-0"
                  >
                    <Trash2 size={11} />
                  </button>
                </div>
                <div className="text-xs text-aethon-muted mt-0.5 truncate">{agent.description}</div>
                <div className="flex items-center gap-2 mt-1.5">
                  <span
                    className="text-[10px] font-mono px-1.5 py-0.5 rounded"
                    style={{ color, background: `${color}15` }}
                  >
                    {agent.provider}
                  </span>
                  <span className="text-[10px] text-aethon-muted/60 font-mono truncate">
                    {agent.model?.split('-').slice(0,3).join('-')}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Agent chat panel */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {selected ? (
          <>
            {/* Agent header */}
            <div className="flex items-center gap-3 px-5 py-3 border-b border-aethon-border bg-aethon-surface/40 shrink-0">
              <div className="w-8 h-8 rounded-lg bg-aethon-surface border border-aethon-border flex items-center justify-center">
                <Bot size={15} className="text-aethon-muted" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-white text-sm">{selected.name}</span>
                  <div className={`status-dot ${selected.status}`} />
                </div>
                <div className="text-xs text-aethon-muted">{selected.description}</div>
              </div>
              <button
                onClick={() => clearAgentMemory(selected.id)}
                className="px-2 py-1 text-xs border border-aethon-border text-aethon-muted hover:text-white hover:border-aethon-muted rounded transition-all"
              >
                Clear Memory
              </button>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto px-5 py-4 space-y-3">
              {chatHistory.length === 0 && (
                <div className="flex flex-col items-center justify-center h-full text-center gap-3">
                  <Bot size={32} className="text-aethon-muted/40" />
                  <div>
                    <div className="text-white font-medium mb-1">Chat with {selected.name}</div>
                    <div className="text-sm text-aethon-muted">{selected.description}</div>
                  </div>
                </div>
              )}
              {chatHistory.map((m, i) => (
                <div key={i} className={`flex gap-2 ${m.role === 'user' ? 'flex-row-reverse' : ''}`}>
                  <div className={`px-3 py-2 rounded-xl text-sm max-w-[80%] ${
                    m.role === 'user'
                      ? 'bg-aethon-accent/15 border border-aethon-accent/20 text-white'
                      : 'bg-aethon-surface border border-aethon-border text-aethon-text'
                  }`}>
                    <div className="ai-prose whitespace-pre-wrap">{m.content || (streaming && i === chatHistory.length-1 ? '▋' : '')}</div>
                  </div>
                </div>
              ))}
            </div>

            {/* Input */}
            <div className="shrink-0 px-5 py-3 border-t border-aethon-border">
              <div className="flex gap-2">
                <input
                  value={chatInput}
                  onChange={e => setChatInput(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && sendToAgent()}
                  placeholder={`Message ${selected.name}…`}
                  disabled={streaming}
                  className="flex-1 bg-aethon-bg border border-aethon-border rounded-lg px-3 py-2 text-white text-sm placeholder-aethon-muted focus:outline-none focus:border-aethon-accent/40 transition-colors disabled:opacity-50"
                />
                <button
                  onClick={sendToAgent}
                  disabled={!chatInput.trim() || streaming}
                  className="px-3 py-2 rounded-lg bg-aethon-accent/20 border border-aethon-accent/30 text-aethon-accent disabled:opacity-40 transition-all"
                >
                  {streaming ? <Loader size={14} className="animate-spin" /> : <ChevronRight size={14} />}
                </button>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-center">
            <div>
              <Bot size={40} className="text-aethon-muted/30 mx-auto mb-3" />
              <div className="text-white font-medium mb-1">Select an Agent</div>
              <div className="text-sm text-aethon-muted">Choose an agent to start a conversation</div>
            </div>
          </div>
        )}
      </div>

      {/* Create modal */}
      {showCreate && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
          <div className="bg-aethon-surface border border-aethon-border rounded-xl p-5 w-full max-w-md">
            <div className="flex items-center justify-between mb-4">
              <span className="font-display font-bold text-white">Create Agent</span>
              <button onClick={() => setShowCreate(false)} className="text-aethon-muted hover:text-white">
                <X size={16} />
              </button>
            </div>
            <div className="space-y-3">
              {[
                { key: 'name', label: 'Name', placeholder: 'Agent name' },
                { key: 'description', label: 'Description', placeholder: 'What does this agent do?' },
              ].map(({ key, label, placeholder }) => (
                <div key={key}>
                  <label className="text-xs text-aethon-muted mb-1 block uppercase tracking-wider font-mono">{label}</label>
                  <input
                    value={(newAgent as any)[key]}
                    onChange={e => setNewAgent(a => ({ ...a, [key]: e.target.value }))}
                    placeholder={placeholder}
                    className="w-full bg-aethon-bg border border-aethon-border rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-aethon-accent/40"
                  />
                </div>
              ))}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-aethon-muted mb-1 block uppercase tracking-wider font-mono">Provider</label>
                  <select
                    value={newAgent.provider}
                    onChange={e => setNewAgent(a => ({ ...a, provider: e.target.value }))}
                    className="w-full bg-aethon-bg border border-aethon-border rounded-lg px-3 py-2 text-white text-sm focus:outline-none"
                  >
                    <option value="openai">OpenAI</option>
                    <option value="anthropic">Anthropic</option>
                    <option value="gemini">Gemini</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs text-aethon-muted mb-1 block uppercase tracking-wider font-mono">Model</label>
                  <input
                    value={newAgent.model}
                    onChange={e => setNewAgent(a => ({ ...a, model: e.target.value }))}
                    className="w-full bg-aethon-bg border border-aethon-border rounded-lg px-3 py-2 text-white text-sm focus:outline-none"
                  />
                </div>
              </div>
              <div>
                <label className="text-xs text-aethon-muted mb-1 block uppercase tracking-wider font-mono">System Prompt (optional)</label>
                <textarea
                  value={newAgent.systemPrompt}
                  onChange={e => setNewAgent(a => ({ ...a, systemPrompt: e.target.value }))}
                  rows={3}
                  placeholder="Custom instructions for this agent…"
                  className="w-full bg-aethon-bg border border-aethon-border rounded-lg px-3 py-2 text-white text-sm focus:outline-none resize-none"
                />
              </div>
              <button
                onClick={createAgent}
                disabled={!newAgent.name || creating}
                className="w-full py-2.5 rounded-lg bg-aethon-accent/20 border border-aethon-accent/30 text-aethon-accent font-semibold text-sm transition-all hover:bg-aethon-accent/30 disabled:opacity-40"
              >
                {creating ? 'Creating…' : 'Create Agent'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

'use client';
import { useState, useRef, useEffect, useCallback } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Send, Plus, Trash2, ChevronDown, Loader, Bot, User, Sparkles, Circle } from 'lucide-react';
import { streamChat } from '../../../lib/api';
import { api } from '../../../lib/api';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  provider?: string;
  model?: string;
  timestamp: string;
  streaming?: boolean;
}

interface Config {
  provider: string;
  model: string;
  systemPrompt: string;
  temperature: number;
}

const PROVIDERS = [
  { id: 'openai', name: 'OpenAI', models: ['gpt-4o', 'gpt-4o-mini', 'gpt-3.5-turbo'] },
  { id: 'anthropic', name: 'Anthropic', models: ['claude-opus-4-6', 'claude-sonnet-4-6', 'claude-haiku-4-5-20251001'] },
  { id: 'gemini', name: 'Google Gemini', models: ['gemini-1.5-pro', 'gemini-1.5-flash'] },
];

const PROVIDER_COLORS: Record<string, string> = {
  openai: '#10a37f',
  anthropic: '#d97757',
  gemini: '#4285f4',
};

export default function ChatPage() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [config, setConfig] = useState<Config>({
    provider: 'openai',
    model: 'gpt-4o',
    systemPrompt: 'You are AETHON, an advanced AI assistant. Be helpful, precise, and insightful.',
    temperature: 0.7,
  });
  const [isStreaming, setIsStreaming] = useState(false);
  const [showConfig, setShowConfig] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const abortRef = useRef<() => void>();

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = useCallback(async () => {
    const text = input.trim();
    if (!text || isStreaming) return;

    const userMsg: Message = {
      id: crypto.randomUUID(),
      role: 'user',
      content: text,
      timestamp: new Date().toISOString(),
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsStreaming(true);

    const assistantId = crypto.randomUUID();
    setMessages(prev => [...prev, {
      id: assistantId,
      role: 'assistant',
      content: '',
      provider: config.provider,
      model: config.model,
      timestamp: new Date().toISOString(),
      streaming: true,
    }]);

    try {
      const history = [...messages, userMsg].map(m => ({ role: m.role, content: m.content }));

      await streamChat(
        {
          provider: config.provider,
          model: config.model,
          messages: history,
          systemPrompt: config.systemPrompt,
          temperature: config.temperature,
        },
        (chunk) => {
          setMessages(prev => prev.map(m =>
            m.id === assistantId ? { ...m, content: m.content + chunk } : m
          ));
        },
        () => {
          setMessages(prev => prev.map(m =>
            m.id === assistantId ? { ...m, streaming: false } : m
          ));
        }
      );
    } catch (err: any) {
      setMessages(prev => prev.map(m =>
        m.id === assistantId
          ? { ...m, content: `Error: ${err.message}`, streaming: false }
          : m
      ));
    } finally {
      setIsStreaming(false);
    }
  }, [input, messages, config, isStreaming]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const clearChat = () => {
    setMessages([]);
    setIsStreaming(false);
  };

  const providerColor = PROVIDER_COLORS[config.provider] || '#00d4ff';

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-3 border-b border-aethon-border bg-aethon-surface/50 shrink-0">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <Circle size={6} className="fill-aethon-accent text-aethon-accent" />
            <span className="font-display font-semibold text-white text-sm">Chat</span>
          </div>
          <div
            className="px-2 py-0.5 rounded text-[10px] font-mono border"
            style={{ color: providerColor, borderColor: `${providerColor}40`, background: `${providerColor}10` }}
          >
            {config.model}
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowConfig(!showConfig)}
            className={`px-2.5 py-1.5 rounded text-xs border transition-all ${
              showConfig
                ? 'bg-aethon-accent/10 border-aethon-accent/30 text-aethon-accent'
                : 'border-aethon-border text-aethon-muted hover:text-white hover:border-aethon-border'
            }`}
          >
            Config
          </button>
          <button
            onClick={clearChat}
            className="p-1.5 rounded text-aethon-muted hover:text-aethon-error transition-colors"
            title="Clear chat"
          >
            <Trash2 size={14} />
          </button>
        </div>
      </div>

      {/* Config panel */}
      {showConfig && (
        <div className="px-5 py-3 border-b border-aethon-border bg-aethon-surface/30 flex flex-wrap gap-4 text-xs shrink-0">
          {/* Provider */}
          <div>
            <label className="text-aethon-muted block mb-1 uppercase tracking-wider font-mono text-[10px]">Provider</label>
            <select
              value={config.provider}
              onChange={e => {
                const p = PROVIDERS.find(p => p.id === e.target.value)!;
                setConfig(c => ({ ...c, provider: p.id, model: p.models[0] }));
              }}
              className="bg-aethon-bg border border-aethon-border rounded px-2 py-1 text-white text-xs focus:outline-none focus:border-aethon-accent/50"
            >
              {PROVIDERS.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          </div>
          {/* Model */}
          <div>
            <label className="text-aethon-muted block mb-1 uppercase tracking-wider font-mono text-[10px]">Model</label>
            <select
              value={config.model}
              onChange={e => setConfig(c => ({ ...c, model: e.target.value }))}
              className="bg-aethon-bg border border-aethon-border rounded px-2 py-1 text-white text-xs focus:outline-none focus:border-aethon-accent/50"
            >
              {PROVIDERS.find(p => p.id === config.provider)?.models.map(m => (
                <option key={m} value={m}>{m}</option>
              ))}
            </select>
          </div>
          {/* Temperature */}
          <div>
            <label className="text-aethon-muted block mb-1 uppercase tracking-wider font-mono text-[10px]">
              Temp: {config.temperature}
            </label>
            <input
              type="range" min="0" max="1" step="0.1"
              value={config.temperature}
              onChange={e => setConfig(c => ({ ...c, temperature: parseFloat(e.target.value) }))}
              className="w-24 accent-aethon-accent"
            />
          </div>
          {/* System prompt */}
          <div className="flex-1 min-w-48">
            <label className="text-aethon-muted block mb-1 uppercase tracking-wider font-mono text-[10px]">System Prompt</label>
            <input
              type="text"
              value={config.systemPrompt}
              onChange={e => setConfig(c => ({ ...c, systemPrompt: e.target.value }))}
              className="w-full bg-aethon-bg border border-aethon-border rounded px-2 py-1 text-white text-xs focus:outline-none focus:border-aethon-accent/50"
            />
          </div>
        </div>
      )}

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
        {messages.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center text-center">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-aethon-accent/20 to-aethon-accent2/20 border border-aethon-accent/20 flex items-center justify-center mb-4">
              <Sparkles size={28} className="text-aethon-accent" />
            </div>
            <div className="font-display font-bold text-white text-xl mb-2">AETHON Chat</div>
            <div className="text-aethon-muted text-sm max-w-xs">
              Multi-model AI at your command. Switch between OpenAI, Anthropic, and Gemini instantly.
            </div>
            <div className="mt-6 flex flex-wrap gap-2 justify-center">
              {['Explain quantum computing', 'Write a Python web scraper', 'Summarize my codebase'].map(s => (
                <button
                  key={s}
                  onClick={() => { setInput(s); textareaRef.current?.focus(); }}
                  className="px-3 py-1.5 text-xs rounded-full border border-aethon-border text-aethon-muted hover:text-white hover:border-aethon-accent/30 transition-all"
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((msg) => (
          <div key={msg.id} className={`flex gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
            {/* Avatar */}
            <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 mt-0.5 ${
              msg.role === 'user'
                ? 'bg-aethon-accent/20 border border-aethon-accent/30'
                : 'bg-aethon-surface border border-aethon-border'
            }`}>
              {msg.role === 'user'
                ? <User size={13} className="text-aethon-accent" />
                : <Bot size={13} className="text-aethon-muted" />
              }
            </div>

            {/* Bubble */}
            <div className={`max-w-[80%] ${msg.role === 'user' ? 'items-end' : 'items-start'} flex flex-col gap-1`}>
              {msg.role === 'assistant' && msg.model && (
                <div
                  className="text-[10px] font-mono px-1.5 py-0.5 rounded"
                  style={{
                    color: PROVIDER_COLORS[msg.provider || ''] || '#64748b',
                    background: `${PROVIDER_COLORS[msg.provider || ''] || '#64748b'}10`
                  }}
                >
                  {msg.model}
                </div>
              )}
              <div className={`rounded-xl px-4 py-2.5 text-sm leading-relaxed ${
                msg.role === 'user'
                  ? 'bg-aethon-accent/15 border border-aethon-accent/25 text-white ml-auto'
                  : 'bg-aethon-surface border border-aethon-border text-aethon-text'
              }`}>
                {msg.role === 'assistant' ? (
                  <div className="ai-prose">
                    <ReactMarkdown remarkPlugins={[remarkGfm]}>
                      {msg.content || (msg.streaming ? '▋' : '')}
                    </ReactMarkdown>
                    {msg.streaming && msg.content && (
                      <span className="inline-block w-1 h-4 bg-aethon-accent cursor-blink ml-0.5 align-text-bottom" />
                    )}
                  </div>
                ) : (
                  <span className="whitespace-pre-wrap">{msg.content}</span>
                )}
              </div>
            </div>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className="shrink-0 px-5 py-4 border-t border-aethon-border bg-aethon-surface/30">
        <div className="flex items-end gap-2">
          <div className="flex-1 relative">
            <textarea
              ref={textareaRef}
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Message AETHON… (Enter to send, Shift+Enter for newline)"
              rows={1}
              className="w-full bg-aethon-bg border border-aethon-border rounded-xl px-4 py-3 text-white text-sm placeholder-aethon-muted resize-none focus:outline-none focus:border-aethon-accent/40 transition-colors"
              style={{ maxHeight: '120px', minHeight: '44px' }}
              onInput={e => {
                const t = e.target as HTMLTextAreaElement;
                t.style.height = 'auto';
                t.style.height = Math.min(t.scrollHeight, 120) + 'px';
              }}
            />
          </div>
          <button
            onClick={sendMessage}
            disabled={!input.trim() || isStreaming}
            className="w-10 h-10 rounded-xl flex items-center justify-center transition-all shrink-0 disabled:opacity-40 disabled:cursor-not-allowed"
            style={{
              background: isStreaming ? 'rgba(0,212,255,0.1)' : 'rgba(0,212,255,0.2)',
              border: '1px solid rgba(0,212,255,0.3)',
            }}
          >
            {isStreaming
              ? <Loader size={15} className="text-aethon-accent animate-spin" />
              : <Send size={15} className="text-aethon-accent" />
            }
          </button>
        </div>
      </div>
    </div>
  );
}

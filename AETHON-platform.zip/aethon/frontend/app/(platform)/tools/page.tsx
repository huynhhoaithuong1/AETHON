'use client';
import { useState, useEffect } from 'react';
import { Wrench, Play, Circle, Zap, CheckCircle, Loader, ChevronRight } from 'lucide-react';
import { api } from '../../../lib/api';

const CATEGORY_COLORS: Record<string, string> = {
  search: '#00d4ff',
  compute: '#7c3aed',
  filesystem: '#f59e0b',
  utility: '#10b981',
  ai: '#d97757',
};

export default function ToolsPage() {
  const [tools, setTools] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<any | null>(null);
  const [params, setParams] = useState('{}');
  const [result, setResult] = useState<any | null>(null);
  const [executing, setExecuting] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    api.tools.list().then(setTools).finally(() => setLoading(false));
  }, []);

  const execute = async () => {
    if (!selected) return;
    setExecuting(true);
    setResult(null);
    setError('');
    try {
      const p = JSON.parse(params);
      const res = await api.tools.execute(selected.id, p);
      setResult(res);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setExecuting(false);
    }
  };

  return (
    <div className="h-full flex overflow-hidden">
      {/* Tools list */}
      <div className="w-72 flex flex-col border-r border-aethon-border shrink-0 bg-aethon-surface/20">
        <div className="flex items-center gap-2 px-4 py-3 border-b border-aethon-border">
          <Circle size={6} className="fill-aethon-accent text-aethon-accent" />
          <span className="font-display font-semibold text-white text-sm">Tool Registry</span>
          <span className="text-xs text-aethon-muted font-mono ml-auto">({tools.length})</span>
        </div>
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {loading
            ? [...Array(5)].map((_, i) => <div key={i} className="h-14 rounded-lg shimmer" />)
            : tools.map((tool) => {
              const color = CATEGORY_COLORS[tool.category] || '#64748b';
              const isSelected = selected?.id === tool.id;
              return (
                <div
                  key={tool.id}
                  onClick={() => { setSelected(tool); setResult(null); setError(''); }}
                  className={`p-3 rounded-lg cursor-pointer border transition-all ${
                    isSelected
                      ? 'bg-aethon-accent/10 border-aethon-accent/30'
                      : 'border-transparent hover:bg-aethon-surface hover:border-aethon-border'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <div className="w-6 h-6 rounded flex items-center justify-center" style={{ background: `${color}15` }}>
                      <Wrench size={11} style={{ color }} />
                    </div>
                    <span className="font-medium text-sm text-white">{tool.name}</span>
                    {tool.enabled && <CheckCircle size={10} className="ml-auto text-aethon-success" />}
                  </div>
                  <div className="text-xs text-aethon-muted pl-8">{tool.description}</div>
                  <div className="pl-8 mt-1">
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded" style={{ color, background: `${color}15` }}>
                      {tool.category}
                    </span>
                  </div>
                </div>
              );
            })
          }
        </div>
      </div>

      {/* Tool executor */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {selected ? (
          <>
            <div className="px-5 py-3 border-b border-aethon-border bg-aethon-surface/40 shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg flex items-center justify-center"
                  style={{ background: `${CATEGORY_COLORS[selected.category] || '#64748b'}15`, border: `1px solid ${CATEGORY_COLORS[selected.category] || '#64748b'}30` }}>
                  <Wrench size={16} style={{ color: CATEGORY_COLORS[selected.category] }} />
                </div>
                <div>
                  <div className="font-semibold text-white text-sm">{selected.name}</div>
                  <div className="text-xs text-aethon-muted">{selected.description}</div>
                </div>
                <span className={`ml-auto text-xs font-mono px-2 py-0.5 rounded border ${
                  selected.enabled ? 'text-aethon-success border-aethon-success/30 bg-aethon-success/10' : 'text-aethon-error border-aethon-error/30'
                }`}>
                  {selected.enabled ? 'enabled' : 'disabled'}
                </span>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-5 space-y-4">
              {/* Params */}
              <div>
                <label className="text-xs text-aethon-muted uppercase tracking-wider font-mono block mb-2">
                  Parameters (JSON)
                </label>
                <textarea
                  value={params}
                  onChange={e => setParams(e.target.value)}
                  rows={6}
                  spellCheck={false}
                  className="w-full bg-aethon-bg border border-aethon-border rounded-lg px-3 py-2 text-white text-sm font-mono focus:outline-none focus:border-aethon-accent/40 resize-none"
                />
              </div>

              <button
                onClick={execute}
                disabled={!selected.enabled || executing}
                className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-aethon-accent/20 border border-aethon-accent/30 text-aethon-accent font-semibold text-sm transition-all hover:bg-aethon-accent/30 disabled:opacity-40"
              >
                {executing ? <Loader size={14} className="animate-spin" /> : <Play size={14} />}
                {executing ? 'Executing…' : 'Execute Tool'}
              </button>

              {error && (
                <div className="bg-aethon-error/10 border border-aethon-error/30 rounded-lg p-3 text-sm text-aethon-error font-mono">
                  {error}
                </div>
              )}

              {result && (
                <div>
                  <div className="text-xs text-aethon-muted uppercase tracking-wider font-mono mb-2">Result</div>
                  <div className="bg-aethon-bg border border-aethon-border rounded-lg p-4">
                    <pre className="text-sm text-aethon-text font-mono whitespace-pre-wrap">
                      {JSON.stringify(result, null, 2)}
                    </pre>
                  </div>
                  <div className="text-[10px] text-aethon-muted font-mono mt-1">
                    {result.timestamp}
                  </div>
                </div>
              )}
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-center">
            <div>
              <Wrench size={40} className="text-aethon-muted/30 mx-auto mb-3" />
              <div className="text-white font-medium mb-1">Select a Tool</div>
              <div className="text-sm text-aethon-muted">Choose a tool from the registry to execute it</div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

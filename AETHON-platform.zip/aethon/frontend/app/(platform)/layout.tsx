'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  LayoutDashboard, MessageSquare, Terminal, Bot, Wrench, Settings,
  Zap, ChevronRight, Activity
} from 'lucide-react';
import { useSystemStatus } from '../../hooks/useSystemStatus';

const NAV = [
  { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/chat', label: 'Chat', icon: MessageSquare },
  { href: '/terminal', label: 'Terminal', icon: Terminal },
  { href: '/agents', label: 'Agents', icon: Bot },
  { href: '/tools', label: 'Tools', icon: Wrench },
];

export default function PlatformLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const { status } = useSystemStatus();

  return (
    <div className="flex h-screen overflow-hidden bg-aethon-bg grid-bg">
      {/* Sidebar */}
      <aside className="w-56 flex flex-col border-r border-aethon-border bg-aethon-surface shrink-0 relative z-10">
        {/* Logo */}
        <div className="flex items-center gap-2 px-4 py-4 border-b border-aethon-border">
          <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-aethon-accent to-aethon-accent2 flex items-center justify-center">
            <Zap size={14} className="text-white" />
          </div>
          <div>
            <div className="font-display font-bold text-white text-base leading-none">
              <span className="text-aethon-accent">AE</span>THON
            </div>
            <div className="text-[9px] text-aethon-muted tracking-widest uppercase">AI Platform</div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-2 py-3 space-y-0.5 overflow-y-auto">
          {NAV.map(({ href, label, icon: Icon }) => {
            const active = pathname === href || pathname.startsWith(href + '/');
            return (
              <Link
                key={href}
                href={href}
                className={`flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm transition-all group
                  ${active
                    ? 'bg-aethon-accent/10 text-aethon-accent border border-aethon-accent/20'
                    : 'text-aethon-muted hover:text-white hover:bg-white/5'
                  }`}
              >
                <Icon size={15} className={active ? 'text-aethon-accent' : 'text-aethon-muted group-hover:text-white'} />
                <span className="flex-1">{label}</span>
                {active && <ChevronRight size={12} className="text-aethon-accent opacity-60" />}
              </Link>
            );
          })}
        </nav>

        {/* System status */}
        <div className="px-3 py-3 border-t border-aethon-border space-y-2">
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-1.5 text-aethon-muted">
              <Activity size={11} />
              <span>System</span>
            </div>
            <div className={`status-dot ${status === 'online' ? 'online' : status === 'connecting' ? 'running' : 'error'}`} />
          </div>
          <div className="text-[10px] text-aethon-muted/60 font-mono">
            v1.0.0 · {status}
          </div>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 overflow-hidden relative">
        {children}
      </main>
    </div>
  );
}

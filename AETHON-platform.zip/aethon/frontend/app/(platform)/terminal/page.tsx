'use client';
import { useState, useRef, useEffect, useCallback } from 'react';
import { Terminal as TermIcon, ChevronRight, Loader, Info, Trash2 } from 'lucide-react';
import { api } from '../../../lib/api';

interface HistoryEntry {
  id: string;
  command: string;
  stdout: string;
  stderr: string;
  exitCode: number;
  timestamp: string;
  duration: number;
}

const GREETING = `
AETHON Terminal v1.0.0
──────────────────────────────────────────
Secure command execution environment
Type 'help' for available commands.
──────────────────────────────────────────
`;

const BUILTIN_HELP = `Available commands:
  ls, pwd, echo, date, whoami, uname, cat
  head, tail, wc, grep, find, ps, df, du
  node, npm, python3, git
  
Built-in terminal commands:
  help     Show this help message
  clear    Clear terminal history
  history  Show command history
`;

export default function TerminalPage() {
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [inputHistory, setInputHistory] = useState<string[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const [cwd, setCwd] = useState('~');

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [history, loading]);

  const execute = useCallback(async (cmd: string) => {
    const command = cmd.trim();
    if (!command) return;

    // Store in input history
    setInputHistory(prev => [command, ...prev.slice(0, 49)]);
    setHistoryIndex(-1);

    // Handle built-ins
    if (command === 'clear') {
      setHistory([]);
      return;
    }
    if (command === 'help') {
      setHistory(prev => [...prev, {
        id: crypto.randomUUID(),
        command,
        stdout: BUILTIN_HELP,
        stderr: '',
        exitCode: 0,
        timestamp: new Date().toISOString(),
        duration: 0,
      }]);
      return;
    }

    setLoading(true);
    const start = Date.now();

    try {
      const result = await api.terminal.execute(command, cwd);
      const entry: HistoryEntry = {
        id: crypto.randomUUID(),
        command,
        stdout: result.stdout || '',
        stderr: result.stderr || '',
        exitCode: result.exitCode ?? 0,
        timestamp: new Date().toISOString(),
        duration: Date.now() - start,
      };
      setHistory(prev => [...prev, entry]);
    } catch (err: any) {
      setHistory(prev => [...prev, {
        id: crypto.randomUUID(),
        command,
        stdout: '',
        stderr: err.message,
        exitCode: 1,
        timestamp: new Date().toISOString(),
        duration: Date.now() - start,
      }]);
    } finally {
      setLoading(false);
    }
  }, [cwd]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      execute(input);
      setInput('');
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      const next = Math.min(historyIndex + 1, inputHistory.length - 1);
      setHistoryIndex(next);
      setInput(inputHistory[next] || '');
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      const next = Math.max(historyIndex - 1, -1);
      setHistoryIndex(next);
      setInput(next === -1 ? '' : inputHistory[next]);
    }
  };

  return (
    <div
      className="h-full flex flex-col bg-[#060a10]"
      onClick={() => inputRef.current?.focus()}
    >
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-aethon-border bg-aethon-surface/60 shrink-0">
        <div className="flex items-center gap-2">
          <div className="flex gap-1.5">
            <div className="w-2.5 h-2.5 rounded-full bg-[#ef4444]" />
            <div className="w-2.5 h-2.5 rounded-full bg-[#f59e0b]" />
            <div className="w-2.5 h-2.5 rounded-full bg-[#10b981]" />
          </div>
          <div className="flex items-center gap-1.5 ml-3">
            <TermIcon size={12} className="text-aethon-success" />
            <span className="text-xs font-mono text-aethon-muted">aethon://terminal</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setHistory([])}
            className="p-1 text-aethon-muted hover:text-white transition-colors"
            title="Clear"
          >
            <Trash2 size={13} />
          </button>
          <div className="flex items-center gap-1 text-xs text-aethon-muted font-mono">
            <Info size={11} />
            <span>{history.length} entries</span>
          </div>
        </div>
      </div>

      {/* Terminal output */}
      <div className="flex-1 overflow-y-auto p-4 terminal-text">
        {/* Greeting */}
        <pre className="text-aethon-success/70 text-xs mb-4 whitespace-pre">{GREETING}</pre>

        {history.map((entry) => (
          <div key={entry.id} className="mb-3">
            {/* Command line */}
            <div className="flex items-center gap-2 text-xs mb-1">
              <span className="text-aethon-success">aethon</span>
              <span className="text-aethon-muted">@</span>
              <span className="text-aethon-accent">system</span>
              <span className="text-aethon-muted">:</span>
              <span className="text-[#7c3aed]">{cwd}</span>
              <span className="text-aethon-muted">$</span>
              <span className="text-white">{entry.command}</span>
              <span className="ml-auto text-aethon-muted/40 text-[10px]">{entry.duration}ms</span>
            </div>
            {/* Output */}
            {entry.stdout && (
              <pre className="text-aethon-text/80 text-xs whitespace-pre-wrap pl-4 leading-relaxed">
                {entry.stdout}
              </pre>
            )}
            {entry.stderr && (
              <pre className="text-aethon-error text-xs whitespace-pre-wrap pl-4 leading-relaxed">
                {entry.stderr}
              </pre>
            )}
            {entry.exitCode !== 0 && (
              <div className="text-aethon-error/60 text-[10px] pl-4 font-mono">
                exit code: {entry.exitCode}
              </div>
            )}
          </div>
        ))}

        {loading && (
          <div className="flex items-center gap-2 text-xs text-aethon-accent/60 mb-3">
            <Loader size={11} className="animate-spin" />
            <span className="font-mono">executing...</span>
          </div>
        )}

        {/* Current input line */}
        <div className="flex items-center gap-2 text-xs">
          <span className="text-aethon-success">aethon</span>
          <span className="text-aethon-muted">@</span>
          <span className="text-aethon-accent">system</span>
          <span className="text-aethon-muted">:</span>
          <span className="text-[#7c3aed]">{cwd}</span>
          <span className="text-aethon-muted">$</span>
          <input
            ref={inputRef}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            disabled={loading}
            className="flex-1 bg-transparent text-white outline-none font-mono text-xs caret-aethon-accent disabled:opacity-50"
            autoComplete="off"
            spellCheck={false}
          />
        </div>

        <div ref={bottomRef} />
      </div>
    </div>
  );
}

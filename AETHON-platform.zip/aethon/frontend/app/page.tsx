'use client';
import { usePathname, useRouter } from 'next/navigation';
import { useEffect } from 'react';

export default function HomePage() {
  const router = useRouter();
  useEffect(() => { router.replace('/dashboard'); }, []);
  return (
    <div className="flex items-center justify-center h-screen bg-aethon-bg">
      <div className="text-center">
        <div className="text-4xl font-display font-bold text-white mb-2">
          <span className="text-aethon-accent">AE</span>THON
        </div>
        <div className="text-aethon-muted text-sm">Loading platform...</div>
      </div>
    </div>
  );
}
